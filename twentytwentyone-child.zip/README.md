# 2021
Child theme for 2021 with several post types


1.    Luo uusi lapsiteema pohjautuen WordPressin Twenty Twentyone teemaan.

2.     Luo teemaan uusi sisältötyyppi "Case studies". Tälle sisältötyypille määritellään tieto siitä mihin erikoistumisalueeseen tämä kuuluu. Tällä hetkellä tämä voi olla "Software Development", "Service Design" tai "eCommerce" ja sisältötyypillä voi olla useampi erikoistumisalue.

3.    Luo listaussivu tälle sisältötyypille. Listaussivulla näytetään enintään kolme case studya, jokaiselta erikoistumisalueelta. Esimerkiksi kolmella erikoistumisalueella tällä listaussivulla näytetään siis enintään yhdeksän eri case studya. Yksi case study näytetään kuinkin sivulla vain kerran.

4.    Listauksessa näytetään case studyn nimi, julkaisuajankohta (j.n.Y muodossa), ote (enintään 20 sanaa) sekä lue lisää linkki. Listauksessa näytetään myös kuva, jos case studylle lisätty kuva on vaakakuva. Jos artikkeliin on liitetty useampi erikoistumisalue, näytetään listauksessa myös muut kyseiseen artikkeliin liitetyt erikoistumisalueet.

5.    Toimita lapsiteema meille joko zip-tiedostona tai esim. Github-linkkinä. Kiinnitä huomiota siihen, että teema on selkeä ja hyvin jäsennelty.



<h1>Todo</h1>
____________________________________________________________________________________








#no time for these below
9. Add a link to load more card for each subcategory, ajax?
10. Make the tags in listing links
11. Use site-nav to make somekind of a menu to see more case studies
____________________________________________________________________________________
<h1>Todo</h1>


<h1>Done</h1>
____________________________________________________________________________________


1. Create content type
2. Create content type specification/sub category
   "Software Development", "Service Design",  "eCommerce"
3. Populate db with faux data // Automatically import/export data along the theme
6. In the listing show
   1. <b>Name of study</b>   CHECK
   2. <b>Time of posting</b><i>d.m.yyyy	j.n.Y	7.1.1970</i> CHECK
   3. <p>Excerpt of 20 words</p> CHECK
   4. <b>Read more-link</b> CHECK
   5. If the post has a horizontal picture it is shown CHECK
   6. If the post is in several subcategories they are shown
      edit. Show  _ALL_ subcategories 😂CHECK
7. Make the subtheme clean and well organized
4. Create a card showing a case study. Create a page listing three cards of each subcategory, so a total of nine case studies are shown at the same time

5. A case study is shown only once in the listing page
8. Separate the the card from index to it's own card.php element









____________________________________________________________________________________
<h1>Done</h1>
